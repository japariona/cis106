# Notes 1

## What is Markdown?
Markdown is a way to write normal plain text while still keeping your work organized and readable. Markdown was created by John Gruber in 2004. Markup languages are used to structure documents, similar to HTML or XML, but Markdown is much simpler and easier to work with. One reason it's considered future proof is because it relies on plain text instead of specific software that can become outdated. Markdown files usually use the .md or .markdown extension, and common versions include CommonMark, Github Flavored Markdown (GFM), and MultiMarkdown. Markdown is often used to format documents and convert them into formats like HTML, PDF, Word, or Powerpoint without having to redo the content.

## What is Git?
Git is the version control system used to track changes and keeps a history of edits so progress is recorded and mistakes can be fixed without losing any information. 

## What is GitHub?
Github is the cloud-based platform where that work is stored online. Github acts as a backup for code and project files, so even if a computer breaks or files are lost, the work is still safe and accessible.

## What is Slack?
Slack is a cloud-based communication platform designed for collaboration. Slack allows users to send messages, share files, make voice and video calls, and organize conversations into channels. This makes group communication easier to follow and helps keep everything related to a project in one place instead of spread across emails. 